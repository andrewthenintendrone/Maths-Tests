#pragma once
#define PI 3.14159f

namespace AFMaths
{
    float degreesToRadians(const float& degrees);

    float radiansToDegrees(const float& radians);
}
